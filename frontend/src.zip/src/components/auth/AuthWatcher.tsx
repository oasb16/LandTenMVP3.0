"use client";
import { useEffect } from "react";
import { useSession, signOut } from "next-auth/react";

export default function AuthWatcher({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession();

  useEffect(() => {
    if (status === "unauthenticated") {
      const banner = document.createElement("div");
      banner.style.cssText = `
        position:fixed;top:0;left:0;right:0;
        background:#1c1c1c;color:#fff;
        padding:14px;text-align:center;z-index:9999;font-family:sans-serif;
      `;
      banner.innerHTML = `
        <strong style="color:#ff7070">Session expired</strong>
        &nbsp;Your session is invalid. Please sign in again.
        <button id="signin-btn" style="margin-left:10px;padding:4px 12px;border:none;background:#0070f3;color:white;border-radius:4px;cursor:pointer;">Sign in</button>
      `;
      document.body.appendChild(banner);

      const btn = document.getElementById("signin-btn");
        btn?.addEventListener("click", async () => {
          banner.textContent = "Redirecting to sign-in…";
        try {
          await fetch("/api/auth/signout", { method: "POST" });
        } catch {}
        signOut({ callbackUrl: "/auth/signin" });
      });
    }
  }, [status]);

  return <>{children}</>;
}
          await fetch("/api/auth/signout", { method: "POST" });
