def get_ai_response(message: str) -> str:
    return f"AI says: {message[::-1]}"  # Dummy: reverses the message
