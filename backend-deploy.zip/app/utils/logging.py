def log(msg: str):
    print(f"[LOG] {msg}")
